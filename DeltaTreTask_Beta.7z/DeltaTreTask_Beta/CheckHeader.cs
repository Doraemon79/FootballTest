﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeltaTreTask
{
    /// <summary>
    ///     A check header.
    /// </summary>
    ///
    /// <seealso cref="T:DeltaTreTask.IWriteHeader"/>
    public class CheckHeader : IWriteHeader
    {
        /// <summary>
        ///     Position chd position check.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.ChPosChdPosCheck(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string ChPosChdPosCheck(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByPos = "<th data-field='Pos' data-sortable='true'> Pos </th>";
            string showPos = "<th data-field='Pos' > Pos </th>";

            if (doublePositive)
                strHeader += sortByPos;
            else if (singlePositive)
                strHeader += showPos;

            return strHeader;
        }

        /// <summary>
        ///     Clubchdclub checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chClubchdclubChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chClubchdclubChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByClub = "<th data-field='Club' data-sortable='true'> Club </th>";
            string showClub = "<th data-field='Club' > Club </th>";

            if (doublePositive)
                strHeader += sortByClub;
            else if (singlePositive)
                strHeader += showClub;


            return strHeader;
        }

        /// <summary>
        ///     Playedchdplayed checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chPlayedchdplayedChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chPlayedchdplayedChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByPlayed = "<th data-field='Played' data-sortable='true'> Played </th>";
            string showPlayed = "<th data-field='Played' > Played </th>";

            if (doublePositive)
                strHeader += sortByPlayed;
            else if (singlePositive)
                strHeader += showPlayed;

            return strHeader;
        }

        /// <summary>
        ///     Wonchdwon checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chWonchdwonChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chWonchdwonChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByWon = "<th data-field='Won' data-sortable='true'> Won </th>";
            string showWon = "<th data-field='Won' > Won </th>";

            if (doublePositive)
                strHeader += sortByWon;
            else if (singlePositive)
                strHeader += showWon;

            return strHeader;
        }

        /// <summary>
        ///     Drawnchddrawn checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chDrawnchddrawnChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chDrawnchddrawnChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByDrawn = "<th data-field='Drawn' data-sortable='true'> Drawn </th>";
            string showDrawn = "<th data-field='Drawn' > Drawn </th>";

            if (doublePositive)
                strHeader += sortByDrawn;
            else if (singlePositive)
                strHeader += showDrawn;

            return strHeader;
        }

        /// <summary>
        ///     Lostchdlost checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chLostchdlostChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chLostchdlostChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByLost = "<th data-field='Lost' data-sortable='true'> Lost </th>";
            string showLost = "<th data-field='Lost' > Lost </th>";

            if (doublePositive)
                strHeader += sortByLost;
            else if (singlePositive)
                strHeader += showLost;

            return strHeader;
        }

        /// <summary>
        ///     Chdifchddif checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chdifchddifChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chdifchddifChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByGoalDiff = "<th data-field='Goal_Difference' data-sortable='true'> Goal Difference </th>";
            string showGoalDiff = "<th data-field='Goal_Difference' > Lost </th>";

            if (doublePositive)
                strHeader += sortByGoalDiff;
            else if (singlePositive)
                strHeader += showGoalDiff;

            return strHeader;
        }

        /// <summary>
        ///     Chpointschdpoints checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chpointschdpointsChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chpointschdpointsChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByPoints = "<th data-field='Points' data-sortable='true'> Points </th>";
            string showPoints = "<th data-field='Points' > Points </th>";

            if (doublePositive)
                strHeader += sortByPoints;
            else if (singlePositive)
                strHeader += showPoints;

            return strHeader;
        }

        /// <summary>
        ///     Vict percentchd vic per checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        ///
        /// <seealso cref="M:DeltaTreTask.IWriteHeader.chVictPercentchdVicPerChecker(System.Windows.Forms.CheckBox,System.Windows.Forms.CheckBox)"/>
        public string chVictPercentchdVicPerChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2)
        {

            var doublePositive = box1.Checked && box2.Checked;
            var singlePositive = box2.Checked;
            string strHeader = "";
            string sortByVictoryPercent = "<th data-field='Victory/Played %S' data-sortable='true'> Victory/Played % </th>";
            string showVictoryPercent = "<th data-field='Victory/Played %' > Points </th>";

            if (doublePositive)
                strHeader += sortByVictoryPercent;
            else if (singlePositive)
                strHeader += showVictoryPercent;

            return strHeader;
        }
    }
}
