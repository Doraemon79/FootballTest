﻿using DeltaTreTask;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;

namespace TestProject1
{


    /// <summary>
    ///This is a test class for forminfoTest and is intended
    ///to contain all forminfoTest Unit Tests
    ///</summary>
    [TestClass()]
    public class forminfoTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }




        /// <summary>
        ///A test for CerateHrmlPage
        ///</summary>
        [TestMethod()]
        public void CerateHrmlPageTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value

            string pagecode = string.Empty; // TODO: Initialize to an appropriate value
            try
            {
                target.CerateHrmlPage(pagecode);
            }
            catch (UnauthorizedAccessException ex)
            {
                Assert.IsFalse(target.Path.Contains("C:\\"), "Unauthorized Access Destination ");
            }

        }

        /// <summary>
        ///A test for RunHtml
        ///</summary>
        [TestMethod()]
        public void RunHtmlTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value


            try
            {
                target.RunHtml();
            }
            catch (Exception e)
            {
                // Assert.Fail(target.Path, "The system cannot find the file specified");
            }

        }

        /// <summary>
        ///A test for fillteamlist
        ///</summary>
        [TestMethod()]
        public void fillteamlistTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value
            List<teaminfo> expected = null; // TODO: Initialize to an appropriate value
            List<teaminfo> actual;
            actual = target.fillteamlist();
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for getonlinexml
        ///</summary>
        [TestMethod()]
        public void getonlinexmlTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value

            target.getonlinexml();
            // Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for Fname
        ///</summary>
        [TestMethod()]
        public void FnameTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value

            Assert.IsNotNull(target.Fname, "Please Enter Fname");

        }

        /// <summary>
        ///A test for Path
        ///</summary>
        [TestMethod()]
        public void PathTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value


            Assert.IsFalse(target.Path.Contains("C:\\"), "Unauthorized Access Destination ");
            //Assert.IsTrue(File.Exists(target.Path), "The system cannot find the file specified");
            Assert.IsNotNull(target.Path, "Please Enter Path");


        }

        /// <summary>
        ///A test for URL
        ///</summary>
        [TestMethod()]
        public void URLTest()
        {
            string url = string.Empty; // TODO: Initialize to an appropriate value
            string fname = string.Empty; // TODO: Initialize to an appropriate value
            string path = string.Empty; // TODO: Initialize to an appropriate value
            string[] tricode = new string[] { }; // TODO: Initialize to an appropriate value
            forminfo target = new forminfo(url, fname, path, tricode); // TODO: Initialize to an appropriate value

            Assert.IsNotNull(target.URL, "Please Enter URL");
        }
    }
}
