﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Xml.Linq;
using System.IO;
//using System.Web.Script.Serialization;
namespace DeltaTreTask
{
    public partial class Form1 : Form
    {
        public string path = "";
        public bool isvalid = true;
        public XElement compa;
        List<teaminfo> q = new List<teaminfo>();
        public IWriteHeader _writeHeader = new CheckHeader();
        static private authenticator auth = new authenticator();

        public Form1()
        {
            InitializeComponent();
        }

        class authenticator
        {
            private Dictionary<string, string> Credentials = new Dictionary<string, string>();
            public authenticator()
            {
                //username and password
                Credentials.Add("Admin", "password");
                Credentials.Add("alice", "password2");
            }

            public bool ValidateCredentials(string username, string password)
            {
                return Credentials.Any(entry => entry.Key == username && entry.Value == password);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var isvalid = auth.ValidateCredentials(User.Text, Password.Text);
            //if (isvalid)
            //{
                if (txtsource.Text != "" && path != "" && txtfname.Text != "" && isvalid)
                {
                forminfo forminfo1 = new forminfo(txtsource.Text, txtfname.Text, path, txttricode.Text.Split(','));

           //     forminfo forminfo1 = new forminfo(txtsource.Text, txtfname.Text, path);
                    forminfo1.getonlinexml();
                    q = forminfo1.fillteamlist();
                    #region build tabel header
                    //build tabel header 
                    string header = "";
                    header += _writeHeader.ChPosChdPosCheck(chPos, chdpos);
                    header += _writeHeader.chClubchdclubChecker(chClub, chdclub);
                    header += _writeHeader.chPlayedchdplayedChecker(chPlayed, chdplayed);
                    header += _writeHeader.chWonchdwonChecker(chWon, chdwon);
                    header += _writeHeader.chDrawnchddrawnChecker(chDrawn, chddrawn);
                    header += _writeHeader.chLostchdlostChecker(chLost, chdlost);
                    header += _writeHeader.chdifchddifChecker(chdif, chddif);
                    header += _writeHeader.chpointschdpointsChecker(chpoints, chdpoints);
                    header += _writeHeader.chVictPercentchdVicPerChecker(chVictPercent, chdVicPer);
          //      header += "<th data-field='Percent' data-sortable='true'> Percent </th>";

                #endregion

                #region build tabel tr
                //build tabel tr
                string tr = " ";

                    for (int i = 0; i < int.Parse(comboBox1.Text); i++)
                    {
                        if (i < q.Count)
                        {
                            teaminfo team = q[i];
                            tr += "<tr>";

                            if (chdpos.Checked)
                                tr += " <td>" + team.Pos + "</td>";
                            if (chdclub.Checked)
                                tr += " <td>" + team.Club + "</td>";
                            if (chdplayed.Checked)
                                tr += " <td>" + team.Played + "</td>";
                            if (chdwon.Checked)
                                tr += " <td>" + team.Won + "</td>";
                            if (chddrawn.Checked)
                                tr += " <td>" + team.Drawn + "</td>";
                            if (chdlost.Checked)
                                tr += " <td>" + team.Lost + "</td>";
                            if (chddif.Checked)
                                tr += " <td>" + team.Goal_Difference + "</td>";
                            if (chdpoints.Checked)
                                tr += " <td>" + team.Points + "</td>";
                        if ( chdVicPer.Checked)
                            tr += " <td>" + ((Int32.Parse(team.Won)) * 100)/ (Int32.Parse(team.Played)) + "</td>";

                        tr += " </tr>";
                        }
                    }
                    #endregion

                    #region build html page 
                    // build html page          
                    string pagecpntent = "<link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' rel='stylesheet'/><link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.11.0/bootstrap-table.min.css' rel='stylesheet'/>";
                    pagecpntent += " <table data-toggle='table' data-url='sort=full_name&direction=asc&per_page=100&page=1' data-sort-name='stargazers_count' data-sort-order='desc'> ";
                    pagecpntent += " <thead> <tr> " + header + " </tr>	</thead> " + tr + "</tr>";
                    pagecpntent += " </table><script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.11.0/bootstrap-table.min.js'></script>";

                    #endregion

                    forminfo1.CerateHrmlPage(pagecpntent);

                    forminfo1.RunHtml();


                }
                else
                {
                    if (!isvalid)
                        MessageBox.Show("Please Enter your Username and passsword!!");
                    if (txtsource.Text == "")
                        MessageBox.Show("Please Enter your Source URL!!");
                    if (txtfname.Text == "")
                        MessageBox.Show("Please Enter your File Name!!");
                    if (path == "")
                        MessageBox.Show("Please Browse Output Destination:!!");
                }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <21; i++)
            {
                comboBox1.Items.Add(i.ToString());
            }
            comboBox1.SelectedIndex = 1;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (folderBrowserDialog2.ShowDialog() == DialogResult.OK)
            {
                path = folderBrowserDialog2.SelectedPath;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txttricode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
