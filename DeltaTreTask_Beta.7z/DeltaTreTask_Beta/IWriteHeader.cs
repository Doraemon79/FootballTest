﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeltaTreTask
{
    /// <summary>
    ///     Interface for write header.
    /// </summary>
    public interface IWriteHeader
    {
        /// <summary>
        ///     Position chd position check.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string ChPosChdPosCheck(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Clubchdclub checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chClubchdclubChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Playedchdplayed checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chPlayedchdplayedChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Wonchdwon checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chWonchdwonChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Drawnchddrawn checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chDrawnchddrawnChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Lostchdlost checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chLostchdlostChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Chdifchddif checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chdifchddifChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Chpointschdpoints checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chpointschdpointsChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        /// <summary>
        ///     Vict percentchd vic per checker.
        /// </summary>
        ///
        /// <param name="box1"> The box 1 control. </param>
        /// <param name="box2"> The box 2 control. </param>
        ///
        /// <returns>
        ///     A string.
        /// </returns>
        string chVictPercentchdVicPerChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

    }
}
