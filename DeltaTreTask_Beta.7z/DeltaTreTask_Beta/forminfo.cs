﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;

namespace DeltaTreTask
{
    /// <summary>
    ///  A forminfo.
    /// </summary>
    public class forminfo
    {
        string _url;
        string _fname;
        string _path;
        public string URL { get; set; }
        public string Fname { get; set; }
        public string Path { get; set; }
        public string[] Tricode { get; set; }

        /// <summary>
        ///     Constructor.
        /// </summary>
        ///
        /// <param name="url">      URL of the document. </param>
        /// <param name="fname">    Filename of the file. </param>
        /// <param name="path">     Full pathname of the file. </param>
        /// <param name="tricode">  The tricode. </param>
        public forminfo(string url, string fname, string path, string[] tricode)
        {
            Fname = fname;
            URL = url;
            Path = path + "\\" + fname.ToLower().Replace(".html", "") + ".html";
            Tricode = tricode;
        }

        /// <summary>
        ///     Getonlinexmls this object.
        /// </summary>
        public void getonlinexml()
        {
            if (URL != string.Empty)
            {
                //1-download xml file
                System.Net.WebClient client = new System.Net.WebClient();
                client.DownloadFile(URL, "asd.xml");
                //2 update _ to ''
                string text = File.ReadAllText("asd.xml");
                text = text.Replace("\0", "");
                File.WriteAllText("asd.xml", text, Encoding.UTF8);

            }
            else
                System.Windows.Forms.MessageBox.Show("Empty url");
        }

        /// <summary>
        ///     Gets the fillteamlist.
        /// </summary>
        ///
        /// <returns>
        ///     A List&lt;teaminfo&gt;
        /// </returns>
        public List<teaminfo> fillteamlist()
        {
            try
            {
                XElement compa = XElement.Load("asd.xml");
                List<teaminfo> q = new List<teaminfo>();
                foreach (var item in compa.Elements("feed"))
                {
                    if (item.Attribute("name").Value == "F3" && Tricode[0] == "")
                    {
                        q = (from x in item.Elements("SoccerFeed").Elements("SoccerDocument").Elements("Competition").Elements("TeamStandings").Elements("TeamRecord").Elements("Standing")
                             select new teaminfo
                             {
                                 Drawn = x.Element("Drawn").Value.ToString(),
                                 Pos = x.Element("Position").Value.ToString(),
                                 Lost = x.Element("Lost").Value.ToString(),
                                 Goal_Difference = x.Element("For").Value.ToString(),
                                 Played = x.Element("Played").Value.ToString(),
                                 Points = x.Element("Points").Value.ToString(),
                                 Won = x.Element("Won").Value.ToString(),
                                 Club = (from nameele in item.Elements("SoccerFeed").Elements("SoccerDocument").Elements("Team")
                                         where (string)nameele.Attribute("uID") == x.Parent.Attribute("TeamRef").Value.ToString()
                                         select nameele.Element("Name").Value.ToString()).FirstOrDefault(),
                             }).ToList<teaminfo>();

                    }
                    else if (item.Attribute("name").Value == "F3")
                    {
                        q = (from x in item.Elements("SoccerFeed").Elements("SoccerDocument").Elements("Competition").Elements("TeamStandings").Elements("TeamRecord").Elements("Standing")
                             where Tricode.Contains(compa.Elements("feed").Where(ee => ee.Attribute("name").Value.ToString() == "STATIC").Elements("TEAMDATA").Elements("Team").Where(ee => ee.Attribute("ID").Value.ToString() == x.Parent.Attribute("TeamRef").Value.ToString()).Attributes("TriCode").FirstOrDefault().Value.ToString())
                             select new teaminfo
                             {
                                 Drawn = x.Element("Drawn").Value.ToString(),
                                 Pos = x.Element("Position").Value.ToString(),
                                 Lost = x.Element("Lost").Value.ToString(),
                                 Goal_Difference = x.Element("For").Value.ToString(),
                                 Played = x.Element("Played").Value.ToString(),
                                 Points = x.Element("Points").Value.ToString(),
                                 Won = x.Element("Won").Value.ToString(),
                                 Club = (from nameele in item.Elements("SoccerFeed").Elements("SoccerDocument").Elements("Team")
                                         where (string)nameele.Attribute("uID") == x.Parent.Attribute("TeamRef").Value.ToString()
                                         select nameele.Element("Name").Value.ToString()).FirstOrDefault(),
                             }).ToList<teaminfo>();
                    }
                }
                return q;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        /// <summary>
        ///     Cerate hrml page.
        /// </summary>
        ///
        /// <param name="pagecode"> The pagecode. </param>
        public void CerateHrmlPage(string pagecode)
        {
            if (Directory.Exists(Path.Replace("\\" + Fname.ToLower().Replace(".html", "") + ".html", "")))
            {
                using (FileStream fs = new FileStream(Path, FileMode.Create))
                {
                    using (StreamWriter w = new StreamWriter(fs, Encoding.UTF8))
                    {
                        w.WriteLine(pagecode);


                    }
                }
            }
            else
                System.Windows.Forms.MessageBox.Show("the html file path not Exists");

        }

        /// <summary>
        ///     Executes the HTML operation.
        /// </summary>
        public void RunHtml()
        {
            if (File.Exists(Path))
                System.Diagnostics.Process.Start((Path));
            else
                System.Windows.Forms.MessageBox.Show("the html file path not Exists");
        }
    }
}
