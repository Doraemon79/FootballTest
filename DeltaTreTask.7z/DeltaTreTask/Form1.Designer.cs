﻿namespace DeltaTreTask
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.chpoints = new System.Windows.Forms.CheckBox();
            this.chdif = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.chPos = new System.Windows.Forms.CheckBox();
            this.chClub = new System.Windows.Forms.CheckBox();
            this.chDrawn = new System.Windows.Forms.CheckBox();
            this.chWon = new System.Windows.Forms.CheckBox();
            this.chPlayed = new System.Windows.Forms.CheckBox();
            this.chLost = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chdlost = new System.Windows.Forms.CheckBox();
            this.chdplayed = new System.Windows.Forms.CheckBox();
            this.chdwon = new System.Windows.Forms.CheckBox();
            this.chddrawn = new System.Windows.Forms.CheckBox();
            this.chdclub = new System.Windows.Forms.CheckBox();
            this.chdpos = new System.Windows.Forms.CheckBox();
            this.chddif = new System.Windows.Forms.CheckBox();
            this.chdpoints = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtsource = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.folderBrowserDialog2 = new System.Windows.Forms.FolderBrowserDialog();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txttricode = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chdVicPer = new System.Windows.Forms.CheckBox();
            this.chVictPercent = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(2, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "sort by:";
            // 
            // chpoints
            // 
            this.chpoints.AutoSize = true;
            this.chpoints.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chpoints.Location = new System.Drawing.Point(173, 332);
            this.chpoints.Name = "chpoints";
            this.chpoints.Size = new System.Drawing.Size(65, 18);
            this.chpoints.TabIndex = 2;
            this.chpoints.Text = "Points";
            this.chpoints.UseVisualStyleBackColor = true;
            // 
            // chdif
            // 
            this.chdif.AutoSize = true;
            this.chdif.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdif.Location = new System.Drawing.Point(259, 332);
            this.chdif.Name = "chdif";
            this.chdif.Size = new System.Drawing.Size(118, 18);
            this.chdif.TabIndex = 3;
            this.chdif.Text = "Goal Difference";
            this.chdif.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(71, 528);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(207, 49);
            this.button1.TabIndex = 4;
            this.button1.Text = "open webpage result";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // chPos
            // 
            this.chPos.AutoSize = true;
            this.chPos.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chPos.Location = new System.Drawing.Point(5, 299);
            this.chPos.Name = "chPos";
            this.chPos.Size = new System.Drawing.Size(48, 18);
            this.chPos.TabIndex = 6;
            this.chPos.Text = "Pos";
            this.chPos.UseVisualStyleBackColor = true;
            // 
            // chClub
            // 
            this.chClub.AutoSize = true;
            this.chClub.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chClub.Location = new System.Drawing.Point(5, 332);
            this.chClub.Name = "chClub";
            this.chClub.Size = new System.Drawing.Size(53, 18);
            this.chClub.TabIndex = 7;
            this.chClub.Text = "Club";
            this.chClub.UseVisualStyleBackColor = true;
            // 
            // chDrawn
            // 
            this.chDrawn.AutoSize = true;
            this.chDrawn.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chDrawn.Location = new System.Drawing.Point(173, 299);
            this.chDrawn.Name = "chDrawn";
            this.chDrawn.Size = new System.Drawing.Size(66, 18);
            this.chDrawn.TabIndex = 8;
            this.chDrawn.Text = "Drawn";
            this.chDrawn.UseVisualStyleBackColor = true;
            // 
            // chWon
            // 
            this.chWon.AutoSize = true;
            this.chWon.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chWon.Location = new System.Drawing.Point(74, 332);
            this.chWon.Name = "chWon";
            this.chWon.Size = new System.Drawing.Size(54, 18);
            this.chWon.TabIndex = 9;
            this.chWon.Text = "Won";
            this.chWon.UseVisualStyleBackColor = true;
            // 
            // chPlayed
            // 
            this.chPlayed.AutoSize = true;
            this.chPlayed.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chPlayed.Location = new System.Drawing.Point(71, 299);
            this.chPlayed.Name = "chPlayed";
            this.chPlayed.Size = new System.Drawing.Size(66, 18);
            this.chPlayed.TabIndex = 10;
            this.chPlayed.Text = "Played";
            this.chPlayed.UseVisualStyleBackColor = true;
            // 
            // chLost
            // 
            this.chLost.AutoSize = true;
            this.chLost.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chLost.Location = new System.Drawing.Point(259, 299);
            this.chLost.Name = "chLost";
            this.chLost.Size = new System.Drawing.Size(53, 18);
            this.chLost.TabIndex = 11;
            this.chLost.Text = "Lost";
            this.chLost.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(2, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "Displayed Data:";
            // 
            // chdlost
            // 
            this.chdlost.AutoSize = true;
            this.chdlost.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdlost.Location = new System.Drawing.Point(269, 175);
            this.chdlost.Name = "chdlost";
            this.chdlost.Size = new System.Drawing.Size(53, 18);
            this.chdlost.TabIndex = 20;
            this.chdlost.Text = "Lost";
            this.chdlost.UseVisualStyleBackColor = true;
            // 
            // chdplayed
            // 
            this.chdplayed.AutoSize = true;
            this.chdplayed.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdplayed.Location = new System.Drawing.Point(71, 175);
            this.chdplayed.Name = "chdplayed";
            this.chdplayed.Size = new System.Drawing.Size(66, 18);
            this.chdplayed.TabIndex = 19;
            this.chdplayed.Text = "Played";
            this.chdplayed.UseVisualStyleBackColor = true;
            // 
            // chdwon
            // 
            this.chdwon.AutoSize = true;
            this.chdwon.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdwon.Location = new System.Drawing.Point(71, 205);
            this.chdwon.Name = "chdwon";
            this.chdwon.Size = new System.Drawing.Size(54, 18);
            this.chdwon.TabIndex = 18;
            this.chdwon.Text = "Won";
            this.chdwon.UseVisualStyleBackColor = true;
            // 
            // chddrawn
            // 
            this.chddrawn.AutoSize = true;
            this.chddrawn.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chddrawn.Location = new System.Drawing.Point(172, 175);
            this.chddrawn.Name = "chddrawn";
            this.chddrawn.Size = new System.Drawing.Size(66, 18);
            this.chddrawn.TabIndex = 17;
            this.chddrawn.Text = "Drawn";
            this.chddrawn.UseVisualStyleBackColor = true;
            // 
            // chdclub
            // 
            this.chdclub.AutoSize = true;
            this.chdclub.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdclub.Location = new System.Drawing.Point(5, 205);
            this.chdclub.Name = "chdclub";
            this.chdclub.Size = new System.Drawing.Size(53, 18);
            this.chdclub.TabIndex = 16;
            this.chdclub.Text = "Club";
            this.chdclub.UseVisualStyleBackColor = true;
            // 
            // chdpos
            // 
            this.chdpos.AutoSize = true;
            this.chdpos.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdpos.Location = new System.Drawing.Point(5, 175);
            this.chdpos.Name = "chdpos";
            this.chdpos.Size = new System.Drawing.Size(48, 18);
            this.chdpos.TabIndex = 15;
            this.chdpos.Text = "Pos";
            this.chdpos.UseVisualStyleBackColor = true;
            // 
            // chddif
            // 
            this.chddif.AutoSize = true;
            this.chddif.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chddif.Location = new System.Drawing.Point(269, 205);
            this.chddif.Name = "chddif";
            this.chddif.Size = new System.Drawing.Size(118, 18);
            this.chddif.TabIndex = 14;
            this.chddif.Text = "Goal Difference";
            this.chddif.UseVisualStyleBackColor = true;
            // 
            // chdpoints
            // 
            this.chdpoints.AutoSize = true;
            this.chdpoints.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chdpoints.Location = new System.Drawing.Point(174, 205);
            this.chdpoints.Name = "chdpoints";
            this.chdpoints.Size = new System.Drawing.Size(65, 18);
            this.chdpoints.TabIndex = 13;
            this.chdpoints.Text = "Points";
            this.chdpoints.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(2, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 18);
            this.label2.TabIndex = 21;
            this.label2.Text = "Count of Team To show";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(228, 406);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 22;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(2, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 18);
            this.label4.TabIndex = 23;
            this.label4.Text = "Source URL:";
            // 
            // txtsource
            // 
            this.txtsource.Location = new System.Drawing.Point(108, 4);
            this.txtsource.Name = "txtsource";
            this.txtsource.Size = new System.Drawing.Size(241, 20);
            this.txtsource.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(2, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 18);
            this.label5.TabIndex = 25;
            this.label5.Text = "Output Destination:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(163, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 26;
            this.button2.Text = "Browse";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtfname
            // 
            this.txtfname.Location = new System.Drawing.Point(108, 65);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(241, 20);
            this.txtfname.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(2, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 18);
            this.label6.TabIndex = 27;
            this.label6.Text = "File Name:";
            // 
            // User
            // 
            this.User.Location = new System.Drawing.Point(103, 445);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(100, 20);
            this.User.TabIndex = 29;
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(103, 492);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(100, 20);
            this.Password.TabIndex = 30;
            this.Password.UseSystemPasswordChar = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(2, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 18);
            this.label7.TabIndex = 29;
            this.label7.Text = "Tricode:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txttricode
            // 
            this.txttricode.Location = new System.Drawing.Point(108, 108);
            this.txttricode.Name = "txttricode";
            this.txttricode.Size = new System.Drawing.Size(241, 20);
            this.txttricode.TabIndex = 30;
            this.txttricode.TextChanged += new System.EventHandler(this.txttricode_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(144, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(259, 14);
            this.label8.TabIndex = 31;
            this.label8.Text = "Note: you must sperate between tricode by ,";
            // 
            // chdVicPer
            // 
            this.chdVicPer.AutoSize = true;
            this.chdVicPer.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.chdVicPer.Location = new System.Drawing.Point(5, 238);
            this.chdVicPer.Name = "chdVicPer";
            this.chdVicPer.Size = new System.Drawing.Size(116, 18);
            this.chdVicPer.TabIndex = 33;
            this.chdVicPer.Text = "VictoryPercent";
            this.chdVicPer.UseVisualStyleBackColor = true;
            // 
            // chVictPercent
            // 
            this.chVictPercent.AutoSize = true;
            this.chVictPercent.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.chVictPercent.Location = new System.Drawing.Point(5, 367);
            this.chVictPercent.Name = "chVictPercent";
            this.chVictPercent.Size = new System.Drawing.Size(120, 18);
            this.chVictPercent.TabIndex = 34;
            this.chVictPercent.Text = "Victory Percent";
            this.chVictPercent.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(13, 444);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 18);
            this.label9.TabIndex = 35;
            this.label9.Text = "User";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label10.ForeColor = System.Drawing.Color.Maroon;
            this.label10.Location = new System.Drawing.Point(16, 494);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 18);
            this.label10.TabIndex = 36;
            this.label10.Text = "Password";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 589);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.chVictPercent);
            this.Controls.Add(this.chdVicPer);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txttricode);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.User);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtsource);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chdlost);
            this.Controls.Add(this.chdplayed);
            this.Controls.Add(this.chdwon);
            this.Controls.Add(this.chddrawn);
            this.Controls.Add(this.chdclub);
            this.Controls.Add(this.chdpos);
            this.Controls.Add(this.chddif);
            this.Controls.Add(this.chdpoints);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chLost);
            this.Controls.Add(this.chPlayed);
            this.Controls.Add(this.chWon);
            this.Controls.Add(this.chDrawn);
            this.Controls.Add(this.chClub);
            this.Controls.Add(this.chPos);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chdif);
            this.Controls.Add(this.chpoints);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chpoints;
        private System.Windows.Forms.CheckBox chdif;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chPos;
        private System.Windows.Forms.CheckBox chClub;
        private System.Windows.Forms.CheckBox chDrawn;
        private System.Windows.Forms.CheckBox chWon;
        private System.Windows.Forms.CheckBox chPlayed;
        private System.Windows.Forms.CheckBox chLost;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chdlost;
        private System.Windows.Forms.CheckBox chdplayed;
        private System.Windows.Forms.CheckBox chdwon;
        private System.Windows.Forms.CheckBox chddrawn;
        private System.Windows.Forms.CheckBox chdclub;
        private System.Windows.Forms.CheckBox chdpos;
        private System.Windows.Forms.CheckBox chddif;
        private System.Windows.Forms.CheckBox chdpoints;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtsource;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog2;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox User;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txttricode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chdVicPer;
        private System.Windows.Forms.CheckBox chVictPercent;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

