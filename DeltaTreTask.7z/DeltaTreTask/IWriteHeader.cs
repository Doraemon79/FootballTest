﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeltaTreTask
{
    public interface IWriteHeader
    {
        string ChPosChdPosCheck(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string chClubchdclubChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string chPlayedchdplayedChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string chWonchdwonChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string chDrawnchddrawnChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string chLostchdlostChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        string chdifchddifChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);

        string chpointschdpointsChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);
        string  chVictPercentchdVicPerChecker(System.Windows.Forms.CheckBox box1, System.Windows.Forms.CheckBox box2);



    }
}
