﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeltaTreTask
{
 public   class teaminfo
    {
        public teaminfo() { }
        public string Pos { get; set; }
        public string Club { get; set; }
        public string Played { get; set; }
        public string Won { get; set; }
        public string Drawn { get; set; }
        public string Lost { get; set; }
        public string Goal_Difference { get; set; }
        public string Points { get; set; }
   }
}
